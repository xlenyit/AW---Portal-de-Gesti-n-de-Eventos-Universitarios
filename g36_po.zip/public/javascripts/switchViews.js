

function openLogin(){
    window.location.href= "/users/login";
}

function openRegister(){
    window.location.href= "/users/register";
}

function showEvents(){
    window.location.href= "/";
}

function renderUsers(eventId){
    window.location.href= `/events/${eventId}eventViewer`;
}